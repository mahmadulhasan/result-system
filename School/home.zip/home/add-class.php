<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];



?>


<section>
    <style>
        .heading {
            font-size: 0.8rem;
            color: red;
        }
    </style>

    <div class="container  text-center text-lg-start gx-lg-5">
        <div class=" card mb-5 px-5 mb-lg-0 text-center overflow-auto" style="z-index: 10">
            <div class="heading">
                <h2 class="my-5 display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 55%)">See Class result</h2>
            </div>
            <table class="table table-striped">

                <tr>
                    <th scope="col">#</th>
                    <th scope="col" style="width:25%;">Session</th>
                    <th scope="col" style="width:25%;">Class</th>
                    <th scope="col" style="width:25%;">Section</th>
                    <th scope="col" style="width:15%;"></th>
                </tr>


                <?php
                    // Assuming you have already established a database connection in $conn
                    $className = $_SESSION['id'] . "_class_details";
                    $sql3 = "SELECT `id`, `class_no`, `section`, `session`
                    FROM `$className` 
                    WHERE 1 
                    ORDER BY `session` DESC, `class_no` ASC, `section`ASC";
                    $result3 = $conn->query($sql3);

                    if ($result3->num_rows > 0) {
                        $count = 1; // Initialize count
                    
                        // Output data of each row
                        while ($row3 = $result3->fetch_assoc()) {
                            $q = $row3['id'];
                            $class = $row3['session'] . "-" . $row3['class_no'] . "-" . strtoupper($row3['section']);
                            echo "<tr>";
                            echo "<th scope='row'>" . $count . "</th>"; // Display count
                            echo "<td>" . $row3['session'] . "</td>";
                            echo "<td>" . $row3['class_no'] . "</td>";
                            echo "<td>" . $row3['section'] . "</td>";
                            echo "<td class='end'>
                                    <a href='edit-class.php?q=" . $row3['id'] . "&S=" . $row3['session'] . "&c=" . $row3['class_no'] . "&s=" . strtoupper($row3['section']) . "'>
                                        <button type='button' class='btn btn-primary justify-content-md-end'>See exams</button>
                                    </a>
                                </td>";

                            echo "</tr>";

                            $count++; // Increment count
                        }
                    } else {
                        echo "<tr><td colspan='4'>No records found</td></tr>";
                    }
                    ?>
            </table>
        </div>
    </div>
</section>




<?php
include "footer.php";
?>