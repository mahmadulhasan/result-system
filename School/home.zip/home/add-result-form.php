<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];
?>

<style>
    body {
        background: linear-gradient(#001f4c, rgb(111, 241, 245));
    }

    p {
        color: #80130f;
    }
</style>

<!-- Section: Design Block -->
<section class="" style="padding:0 !important; top:0 !important">
    <!-- Background image -->
    <div class=" bg-image" style="
        background-image:linear-gradient(180deg, #004183 0%, #001f4c 100%) !important;
        height: 300px;
        "></div>
    <!-- Background image -->

    <div class="card mx-md-5 shadow-5-strong bg-body-tertiary" style="
        margin-top: -100px;
        backdrop-filter: blur(30px);
        ">
        <div class="card-body py-5 px-md-5">

            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">

                    <form method="POST" action="recent_upload.php" enctype="multipart/form-data">
                        <!-- Class details -->
                        <div class="row">
                            <h2 class="fw-bold mb-5">Enter class details</h2>
                            <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="class_no">Class label</label>
                                <select id="class_no" name="class_no" class="form-control border-dark" style="text-transform: uppercase;" required>
                                    <option value=''>--Select--</option>
                                    <option value='1'>1</option>
                                    <option value='2'>2</option>
                                    <option value='3'>3</option>
                                    <option value='4'>4</option>
                                    <option value='5'>5</option>
                                    <option value='6'>6</option>
                                    <option value='7'>7</option>
                                    <option value='8'>8</option>
                                    <option value='9'>9</option>
                                    <option value='10'>10</option>
                                    <option value='11'>11</option>
                                    <option value='12'>12</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="session">Session</label>
                                <select id="session" name="session" class="form-control border-dark" required>
                                    <option value=''>--Select--</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="section">Section</label>
                                <select id="section" name="section" class="form-control border-dark" required>
                                    <option value=''>--Select--</option>
                                </select>
                            </div>
                        </div>

                            <div class="col-md-4 mb-4">
                                <div data-mdb-input-init class="form-outline">
                                    <label class="form-label" for="exam_name">Exam Name</label>
                                    <input type="text" id="exam_name" name="exam_name" class="form-control border-dark"
                                        placeholder="Unit test 1/ Final exam" style="text-transform: uppercase;"
                                        required />
                                </div>
                            </div>
                        </div>
                        <hr>

                        <!-- Time input -->
                        <div class="row">
                            <h2 class="fw-bold mb-5">Time to publish result</h2>
                            <div class="col-md-4 mb-4">
                                <div data-mdb-input-init class="form-outline">
                                    <label class="form-label" for="publish_date">Date</label>
                                    <input type="date" id="publish_date" name="publish_date"
                                        class="form-control border-dark" style="text-transform: uppercase;" required />
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div data-mdb-input-init class="form-outline">
                                    <label class="form-label" for="publish_time">Time</label>
                                    <input type="time" id="publish_time" name="publish_time"
                                        class="form-control border-dark" style="text-transform: uppercase;" required />
                                </div>
                            </div>
                        </div>
                        <hr>

                        <!-- Subject Input -->
                        <h2 class="fw-bold mb-5">Enter marks</h2>
                        <div id="subject-section">
                            <div class="subject-row">
                                <div class="row">
                                    <div class="col-md-4 mb-4">
                                        <div data-mdb-input-init class="form-outline">
                                            <label class="form-label" for="full_marks">Full marks</label>
                                            <input type="text" id="full_marks" name="full_marks"
                                                class="form-control border-dark" placeholder="100"
                                                style="text-transform: uppercase;" required />
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-4 position-relative">
                                        <div data-mdb-input-init class="form-outline">
                                            <label class="form-label" for="pass_marks">Pass marks</label>
                                            <input type="text" id="pass_marks" name="pass_marks"
                                                class="form-control border-dark" placeholder="33"
                                                style="text-transform: uppercase;" required />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <!-- Result upload -->
                        <h2 class="fw-bold mb-5">Upload Result</h2>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div data-mdb-input-init class="form-outline">
                                    <label class="form-label" for="result_file">Upload Result</label>
                                    <p>1. Make sure file type is EXCEL, CSV <br>
                                        2. ROLL, FULL NAME, FATHER NAME and DOB are must to enter <br>
                                        3. Make sure subject name in file is in samw order with subject name you added
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-8 mb-4">
                                <div class="form-outline">
                                    <div class="file-drop-zone">
                                        <label for="formFileLg" class="form-label"><p>Upload result here</p></label>
                                        <input class="form-control form-control-lg border border-dark" id="result_file" type="file" name="result_file"/>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <!-- Checkbox -->
                        <div class="form-check d-flex justify-content-center mb-4">
                            <input class="" type="checkbox" name="confirmation" value="1"
                                id="form2Example33" checked required />
                            <label class="form-check-label" for="form2Example33">
                                Are you sure
                            </label>
                        </div>

                        <!-- Submit -->
                        <div class="form-check d-flex justify-content-center mb-4">
                            <button type="submit" data-mdb-button-init data-mdb-ripple-init
                                class="btn btn-primary btn-block mb-4">
                                Submit
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>


<script>
    function displayFileName() {
        const fileInput = document.getElementById('input-b4a');
        const fileNameDisplay = document.getElementById('file-name');

        if (fileInput.files.length > 0) {
            const fileName = fileInput.files[0].name;
            fileNameDisplay.textContent = `Selected file: ${fileName}`;
        } else {
            fileNameDisplay.textContent = '';
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        const inputs = document.querySelectorAll('input[type="text"], select');
        inputs.forEach(input => {
            input.addEventListener('input', function () {
                this.value = this.value.toUpperCase();
            });
        });
    });
    
    
    // Event listener for when class is selected
    document.getElementById('class_no').addEventListener('change', function () {
        var class_no = this.value;
    
        // Initialize an AJAX request to get sessions based on class number
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_sessions.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    
        xhr.onload = function () {
            if (this.status === 200) {
                // Clear existing options in the session dropdown
                var sessionSelect = document.getElementById('session');
                sessionSelect.innerHTML = '<option value="">--Select--</option>'; // Default option
                
                // Populate session options
                sessionSelect.innerHTML += this.responseText.trim();
                
                // Reset the section dropdown
                document.getElementById('section').innerHTML = '<option value="">--Select--</option>';
            } else {
                alert("Failed to load sessions. Please try again.");
            }
        };
    
        // Send the request with the selected class number
        xhr.send('class_no=' + class_no);
    });
    
    // Event listener for when session is selected
    document.getElementById('session').addEventListener('change', function () {
        var class_no = document.getElementById('class_no').value;
        var session = this.value;
    
        // Initialize an AJAX request to get sections based on class number and session
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_sections.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    
        xhr.onload = function () {
            if (this.status === 200) {
                // Clear existing options in the section dropdown
                var sectionSelect = document.getElementById('section');
                sectionSelect.innerHTML = '<option value="">--Select--</option>'; // Default option
                
                // Populate section options
                sectionSelect.innerHTML += this.responseText.trim();
            } else {
                alert("Failed to load sections. Please try again.");
            }
        };
    
        // Send the request with the selected class number and session
        xhr.send('class_no=' + class_no + '&session=' + session);
    });

    

</script>





<?php
include "footer.php";
?>