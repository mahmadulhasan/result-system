<?php
include_once "../../config.php";
include "header.php";
?>

<style>
    .heading{
        color:grey;
        font-weight:600;
        font-size:3.5rem;
    }
</style>
 
<section class="card mx-5 text-center">
    <h2 class="fw-bold mb-5 text-center">Add Student Details by Excel Sheet</h2>

    <!-- Form with POST method -->
    <form method="POST" action="upload-student-detalis.php" enctype="multipart/form-data" class="text-center">
        <div class="row mx-5">
                            <h2 class="fw-bold mb-5">Enter class details</h2>
                            <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="class_no">Class label</label>
                                <select id="class_no" name="class_no" class="form-control border-dark" style="text-transform: uppercase;" required>
                                    <option value=''>--Select--</option>
                                    <option value='1'>1</option>
                                    <option value='2'>2</option>
                                    <option value='3'>3</option>
                                    <option value='4'>4</option>
                                    <option value='5'>5</option>
                                    <option value='6'>6</option>
                                    <option value='7'>7</option>
                                    <option value='8'>8</option>
                                    <option value='9'>9</option>
                                    <option value='10'>10</option>
                                    <option value='11'>11</option>
                                    <option value='12'>12</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="session">Session</label>
                                <select id="session" name="session" class="form-control border-dark" required>
                                    <option value=''>--Select--</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="section">Section</label>
                                <select id="section" name="section" class="form-control border-dark" required>
                                    <option value=''>--Select--</option>
                                </select>
                            </div>
                        </div>
                        </div>

        <!-- File Upload Section -->
        <div class="col-md-8 mb-4 mx-auto">
            <div class="form-outline">
                <div class="file-drop-zone">
                    <label for="formFileLg" class="form-label">
                        <p>Upload Student Details Excel Sheet Here</p>
                    </label>
                    <input class="form-control form-control-lg border border-dark" id="result_file" type="file" name="result_file" required />
                </div>
            </div>
        </div>

        <!-- Checkbox -->
        <div class="form-check d-flex justify-content-center mb-4">
            <input class="form-check-input" type="checkbox" name="confirmation" value="1" id="form2Example33" checked required />
            <label class="form-check-label" for="form2Example33">
                Are you sure
            </label>
        </div>

        <!-- Submit Button -->
        <div class="form-check d-flex justify-content-center mb-4">
            <button type="submit" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-block mb-4">
                Submit
            </button>
        </div>

    </form>
</section>



<section class="text-center p-3 heading">
    <span>-OR-</span>
</section>

<!--2nd form-->
<section class="card mx-5">
    <h2 class="fw-bold mb-5 text-center">Add Student details</h2>
    <form method="post" action="upload-student-detalis.php">
        <div id="student-container">
            <div class="row mx-5">
                            <h2 class="fw-bold mb-5">Enter class details</h2>
                            <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="class_no">Class label</label>
                                <select id="class_no2" name="class_no2" class="form-control border-dark" style="text-transform: uppercase;" required>
                                    <option value=''>--Select--</option>
                                    <option value='1'>1</option>
                                    <option value='2'>2</option>
                                    <option value='3'>3</option>
                                    <option value='4'>4</option>
                                    <option value='5'>5</option>
                                    <option value='6'>6</option>
                                    <option value='7'>7</option>
                                    <option value='8'>8</option>
                                    <option value='9'>9</option>
                                    <option value='10'>10</option>
                                    <option value='11'>11</option>
                                    <option value='12'>12</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="session">Session</label>
                                <select id="session2" name="session2" class="form-control border-dark" required>
                                    <option value=''>--Select--</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4">
                            <div data-mdb-input-init class="form-outline">
                                <label class="form-label" for="section">Section</label>
                                <select id="section2" name="section2" class="form-control border-dark" required>
                                    <option value=''>--Select--</option>
                                </select>
                            </div>
                        </div>
                    </div>
            <div class="student-row px-5">
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div data-mdb-input-init class="form-outline">
                            <label class="form-label" for="name">Roll no</label>
                            <input type="text" name="roll_no[]" class="form-control border-dark"
                                style="text-transform: uppercase;" required />
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div data-mdb-input-init class="form-outline">
                            <label class="form-label" for="name">Name</label>
                            <input type="text" name="name[]" class="form-control border-dark"
                                style="text-transform: uppercase;" required />
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div data-mdb-input-init class="form-outline">
                            <label class="form-label" for="guardian_name">Guardian Name</label>
                            <input type="text" name="guardian_name[]" class="form-control border-dark"
                                style="text-transform: uppercase;" required />
                        </div>
                    </div>
                    <div class="col-md-4 mb-4 position-relative">
                        <div data-mdb-input-init class="form-outline">
                            <label class="form-label" for="dob">Date of Birth</label>
                            <input type="date" name="dob[]" class="form-control border-dark"
                                style="text-transform: uppercase;" required />
                        </div>
                        <button type="button" class="delete-student btn btn-danger btn-sm position-absolute"
                            style="right: 0; top: 0;">
                            X
                        </button>
                    </div>
                </div> <hr>
            </div>
        </div>
        
        <div class="form-check d-flex justify-content-center mb-4">
            <button type="button" id="add-student" class="btn btn-primary btn-block mb-4">
                Add more Student +
            </button>
        </div>
        <!-- Submit Button -->
        <div class="form-check d-flex justify-content-center mb-4">
            <button type="submit" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-block mb-4">
                Submit
            </button>
        </div>
    </form>
</section>

<script>
    document.getElementById('add-student').addEventListener('click', function () {
        var studentContainer = document.getElementById('student-container');

        var newStudent = `
        <div class="student-row px-5">
          <div class="row">
            <div class="col-md-4 mb-4">
              <div data-mdb-input-init class="form-outline">
                <label class="form-label" for="name">Roll no</label>
                <input type="text" name="roll_no[]" class="form-control border-dark" style="text-transform: uppercase;" required />
              </div>
            </div>
            <div class="col-md-4 mb-4">
              <div data-mdb-input-init class="form-outline">
                <label class="form-label" for="name">Name</label>
                <input type="text" name="name[]" class="form-control border-dark" style="text-transform: uppercase;" required />
              </div>
            </div>
            <div class="col-md-4 mb-4">
              <div data-mdb-input-init class="form-outline">
                <label class="form-label" for="guardian_name">Guardian Name</label>
                <input type="text" name="guardian_name[]" class="form-control border-dark" style="text-transform: uppercase;" required />
              </div>
            </div>
            <div class="col-md-4 mb-4 position-relative">
              <div data-mdb-input-init class="form-outline">
                <label class="form-label" for="dob">Date of Birth</label>
                <input type="date" name="dob[]" class="form-control border-dark" style="text-transform: uppercase;" required />
              </div>
              <button type="button" class="delete-student btn btn-danger btn-sm position-absolute" style="right: 0; top: 0;">
                X
              </button>
            </div>
          </div>
        </div> <hr>`;
        
        studentContainer.insertAdjacentHTML('beforeend', newStudent);
        attachDeleteEvents(); // Ensure the new "X" buttons also have delete functionality
    });

    function attachDeleteEvents() {
        var deleteButtons = document.querySelectorAll('.delete-student');
        deleteButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                this.closest('.student-row').remove(); // Remove the closest student row
            });
        });
    }

    // Attach delete event to existing delete buttons
    attachDeleteEvents();
    
    
    
    // Event listener for when class is selected
    document.getElementById('class_no').addEventListener('change', function () {
        var class_no = this.value;
    
        // Initialize an AJAX request to get sessions based on class number
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_sessions.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    
        xhr.onload = function () {
            if (this.status === 200) {
                // Clear existing options in the session dropdown
                var sessionSelect = document.getElementById('session');
                sessionSelect.innerHTML = '<option value="">--Select--</option>'; // Default option
                
                // Populate session options
                sessionSelect.innerHTML += this.responseText.trim();
                
                // Reset the section dropdown
                document.getElementById('section').innerHTML = '<option value="">--Select--</option>';
            } else {
                alert("Failed to load sessions. Please try again.");
            }
        };
    
        // Send the request with the selected class number
        xhr.send('class_no=' + class_no);
    });
    
    // Event listener for when session is selected
    document.getElementById('session').addEventListener('change', function () {
        var class_no = document.getElementById('class_no').value;
        var session = this.value;
    
        // Initialize an AJAX request to get sections based on class number and session
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_sections.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    
        xhr.onload = function () {
            if (this.status === 200) {
                // Clear existing options in the section dropdown
                var sectionSelect = document.getElementById('section');
                sectionSelect.innerHTML = '<option value="">--Select--</option>'; // Default option
                
                // Populate section options
                sectionSelect.innerHTML += this.responseText.trim();
            } else {
                alert("Failed to load sections. Please try again.");
            }
        };
    
        // Send the request with the selected class number and session
        xhr.send('class_no=' + class_no + '&session=' + session);
    });
    
    
    // Event listener for when 2nd class is selected
    document.getElementById('class_no2').addEventListener('change', function () {
        var class_no = this.value;
    
        // Initialize an AJAX request to get sessions based on class number
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_sessions.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    
        xhr.onload = function () {
            if (this.status === 200) {
                // Clear existing options in the session dropdown
                var sessionSelect = document.getElementById('session2');
                sessionSelect.innerHTML = '<option value="">--Select--</option>'; // Default option
                
                // Populate session options
                sessionSelect.innerHTML += this.responseText.trim();
                
                // Reset the section dropdown
                document.getElementById('section2').innerHTML = '<option value="">--Select--</option>';
            } else {
                alert("Failed to load sessions. Please try again.");
            }
        };
    
        // Send the request with the selected class number
        xhr.send('class_no=' + class_no);
    });
    
    // Event listener for when session is selected
    document.getElementById('session2').addEventListener('change', function () {
        var class_no = document.getElementById('class_no2').value;
        var session = this.value;
    
        // Initialize an AJAX request to get sections based on class number and session
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_sections.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    
        xhr.onload = function () {
            if (this.status === 200) {
                // Clear existing options in the section dropdown
                var sectionSelect = document.getElementById('section2');
                sectionSelect.innerHTML = '<option value="">--Select--</option>'; // Default option
                
                // Populate section options
                sectionSelect.innerHTML += this.responseText.trim();
            } else {
                alert("Failed to load sections. Please try again.");
            }
        };
    
        // Send the request with the selected class number and session
        xhr.send('class_no=' + class_no + '&session=' + session);
    });

</script>


<?php include "footer.php"; ?>

