<?php
include_once "../../config.php";
include_once "header.php";

// Check if the user is not logged in
if ($_SESSION['login'] != true) {
    header("location:../index.php");
    exit;
}
$id = $_SESSION['id'];


$table = $id.'_class_details';

$c_id = $_POST['id'];
$session = $_POST['session'];
$class_no = $_POST['class_no'];
$section = $_POST['section'];



$subject_table = $id.'_'.$session.'_'.$class_no.'_'.$section.'_subject';
$student_table = $id.'_'.$session.'_'.$class_no.'_'.$section.'_student';



// subject insertion
if (isset($_POST['subject_name'])) {
    
        // 3. Check if the table exists
    $tableCheckQuery = "SHOW TABLES LIKE '$subject_table'";
    $tableCheckResult = $conn->query($tableCheckQuery);
    
    if ($tableCheckResult->num_rows == 0) {
        // Table does not exist, create it
        $createTableQuery = "CREATE TABLE `$subject_table` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `subject_name` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
        if ($conn->query($createTableQuery) === TRUE) {
            echo " ";
        } else {
            echo "Error creating table: " . $conn->error;
        }
    }
    
    
    // 1. Retrieve the subject names from the form
    $subjectNames = $_POST['subject_name']; // This is an array
    $subjectsArray = explode(",", $subjectNames);
    
    // 4. Insert values into the table
    foreach ($subjectsArray as $subject) {
        $subject = trim($subject); // Trim whitespace
        
        // Check if the subject is not empty
        if (!empty($subject)) {
            // Sanitize input to prevent SQL injection
            $subject = $conn->real_escape_string($subject);
            
            // Check if the subject already exists in the table
            $checkQuery = "SELECT COUNT(*) FROM `$subject_table` WHERE `subject_name` = UPPER('$subject')";
            $result = $conn->query($checkQuery);
            $row = $result->fetch_row();
            
            if ($row[0] == 0) { // Subject does not exist
                $insertQuery = "INSERT INTO `$subject_table` (`subject_name`) VALUES (UPPER('$subject'))";
                
                if ($conn->query($insertQuery) === TRUE) {
                    
                    echo " ";
                } else {
                    echo "Error inserting subject: " . $conn->error . "<br>";
                }
            } else {
                echo "<script>alert('Subject \"" . strtoupper($subject) . "\" already exists, not inserting.');</script>";
            }
        }
    }

}


?>

<style>
    .section-wrapper{
        display:flex;
        flex-wrap:wrap;
    }
</style>
<!-- Main Section -->
<section class="section-wrapper">
    <div class="box" id="addSubject">
        <i class='bx bx-book-content' style='color:#8ffbf3'></i><br>
        <span>Add Subject</span>
    </div>
    <a href="add-student.php">
        <div class="box" id="addStudent">
            <i class='bx bxs-face' style='color:#8ffbf3'></i><br>
            <span>Add Student</span>
        </div>
    </a>
    <div class="box" id="downloadExcel" c_id="<?php echo $c_id; ?>" data-session="<?php echo $session; ?>" data-class-no="<?php echo $class_no; ?>" data-section="<?php echo $section; ?>">
        <i class='bx bxs-save' style='color:#7df9f0'></i><br>
        <span>Download Excel sheet</span>
    </div>

</section>

<section id="newSectionsContainer" class="container"></section>

<script>
// download exel sheet
document.getElementById('downloadExcel').addEventListener('click', function() {
    // Retrieve values from data attributes
    const q       = this.getAttribute('c_id');
    const session = this.getAttribute('data-session');
    const classNo = this.getAttribute('data-class-no');
    const section = this.getAttribute('data-section');

    // Construct the URL with query parameters
    const url = `download_excel.php?q=${q}&session=${session}&class_no=${classNo}&section=${section}`;

    // Open the URL in a new tab
    window.open(url, '_blank');
});



  // The template for a new subject form section
var newSubject = `
<form action="" method="post">
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($c_id); ?>">
    <input type="hidden" name="session" value="<?php echo htmlspecialchars($session); ?>">
    <input type="hidden" name="class_no" value="<?php echo htmlspecialchars($class_no); ?>">
    <input type="hidden" name="section" value="<?php echo htmlspecialchars($section); ?>">
    
    <div id="subject-section" class="">
        <div class="subject-row">
            <div class="row">
                <div class="mb-4">
                    <div data-mdb-input-init class="form-outline">
                        <label class="form-label" for="subject_name">Subject Name</label>
                        <input type="text" name="subject_name" class="form-control border-dark" placeholder="Bengali, English, Hindi"
                            style="text-transform: uppercase;" required />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button type="submit" class="btn btn-lg btn-primary btn-block mb-4">
        Submit
    </button>
</form>
`;


    // Add new subject section when the "Add Subject" button is clicked
    document.getElementById('addSubject').addEventListener('click', function() {
        document.getElementById('newSectionsContainer').insertAdjacentHTML('beforeend', newSubject);
        attachAddSubjectEvent(); // Attach the event to newly added sections
        attachDeleteEvents();
    });

    

    

    // Initial event attachment for the first form
    attachAddSubjectEvent();

</script>




<!-- ------show subject name and student name----- -->

<section>
    <style>
        .heading {
            font-size: 0.8rem;
            color: red;
        }
    </style>

    <div class="container px-4  px-md-5 text-center text-lg-start ">
        <div class="row gx-lg-5  mb-5">
            <!-- Existing Subject Table -->
            <div class="col-lg-4 mb-5 mb-lg-0 card" style="z-index: 10">
                <div class="heading">
                    <h2 class="my-5  fw-bold ls-tight" style="color: hsl(218, 81%, 55%)">Existing Subject</h2>
                </div>
                <table class="table table-striped">
                    <tr>
                        <th scope="col">Sl no.</th>
                        <th scope="col">Subject Name</th>
                    </tr>

                    <?php
                    // Check if the table exists in the database
                    $table_check_query = "SHOW TABLES LIKE '$subject_table'";
                    $table_check_result = $conn->query($table_check_query);

                    if ($table_check_result && $table_check_result->num_rows > 0) {
                        // Table exists, now proceed with fetching subjects
                        $query = "SELECT `id`, `subject_name` FROM `$subject_table`";
                        $result = $conn->query($query);

                        if ($result->num_rows > 0) {
                            // Output data for each row
                            $serialNo = 1; // To keep track of the serial number
                            while ($row2 = $result->fetch_assoc()) {
                                echo '<tr>
                                        <td>' . $serialNo++ . '</td>
                                        <td>' . htmlspecialchars($row2['subject_name']) . '</td>
                                      </tr>';
                            }
                        } else {
                            echo '<tr><td colspan="2">No subjects found.</td></tr>';
                        }
                    } else {
                        // Table does not exist
                        echo '<tr><td colspan="2">No record found.</td></tr>';
                    }
                    ?>
                </table>
            </div>

            <!-- Student Present Table -->
            <div class="col-lg-8 mb-5 mb-lg-0 position-relative card">
                <div class="heading">
                    <h2 class="my-5  fw-bold ls-tight" style="color: hsl(218, 81%, 55%)">Student Present</h2>
                </div>
                <div class="overflow-auto">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Roll no.</th>
                            <th scope="col">Student ID no.</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">Guardian Name</th>
                            <th scope="col">DOB</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT `id`, `result_id`, `roll_no`, `name`, `gurdian_name`, `date_of_birth`, `school_id`, `class_id` FROM `student_details` WHERE `school_id`= '$id' AND `class_id`= '$c_id'";
                        $result = $conn->query($sql);
                        // Check if there are results and display them
                        if ($result->num_rows > 0) {
                            // Output data for each row
                            $serial_no = 1; // Initialize serial number
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" .$row['roll_no'] . "</td>"; // Display serial number
                                echo "<td>" . $row['result_id'] . "</td>"; // Display Student ID no.
                                echo "<td>" . htmlspecialchars($row['name']) . "</td>"; // Display Student Name
                                echo "<td>" . htmlspecialchars($row['gurdian_name']) . "</td>"; // Display Guardian Name
                                echo "<td>" . htmlspecialchars($row['date_of_birth']) . "</td>"; // Display DOB
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No records found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</section>



<?php include "footer.php"; ?>



