let menu = document.querySelector('.menu-icon');
menu.onclick = () =>{
    menu.classList.toggle("move");
}