<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];
$class_table = $id.'_class_details';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Collect form data
    $session = mysqli_real_escape_string($conn, $_POST['session']);
    $class_no = mysqli_real_escape_string($conn, $_POST['class_no']);
    $section = mysqli_real_escape_string($conn, strtoupper(trim($_POST['section']))); // Convert section to uppercase and trim spaces

    // Check if the class already exists
    $check_query = "SELECT * FROM `$class_table` WHERE `session` = '$session' AND `class_no` = '$class_no' AND `section` = '$section'";
    $result = $conn->query($check_query);

    if ($result->num_rows > 0) {
        // Class already exists
        echo "<script>alert('Class already present');</script>";
    } else {
        // Insert new class details
        $insert_query = "INSERT INTO `$class_table` (`class_no`, `section`, `session`) VALUES ('$class_no', '$section', '$session')";
        
        if ($conn->query($insert_query) === TRUE) {
            echo "<script>alert('Class added successfully!');</script>";
        } else {
            echo "Error: " . $insert_query . "<br>" . $conn->error;
        }
    }
}

?>
    <style>
        .heading {
            font-size: 0.8rem;
            color: red;
        }
        .new-section {
            margin: 20px;
        }
        .student-row {
            margin-bottom: 20px;
        }
        .form-outline {
            margin-bottom: 1rem;
        }
        
    </style>


<!-- Main Section -->
<section class="section-wrapper">
    
    <div class="box" id="addClass">
        <i class='bx bxs-message-alt-add' style='color:#7df9f0'></i> <br>
        <span>Add Class</span>
    </div>
</section>

<!-- Form Section -->

    <div id="newSectionsContainer"></div>
    


<!-- Script to dynamically add new sections -->
<script>
    document.getElementById("addClass").addEventListener("click", function () {
        var newSection = `
        <form method="POST" action="">
        <div class="student-row px-5">
          <div class="row">
            <div class="col-md-4 mb-4">
              <div class="form-outline">
                <label class="form-label" for="class_name">Session</label>
                <input type="text" name="session" class="form-control border-dark" placeholder="Like: 2024-2025" required />
              </div>
            </div>
            <div class="col-md-4 mb-4">
              <div data-mdb-input-init class="form-outline">
                <label class="form-label" for="class_no">Class label</label>
                    <select id="class_no" name="class_no" class="form-control border-dark" style="text-transform: uppercase;" required>
                        <option value=''>--Select--</option>
                        <option value='1'>1</option>
                        <option value='2'>2</option>
                        <option value='3'>3</option>
                        <option value='4'>4</option>
                        <option value='5'>5</option>
                        <option value='6'>6</option>
                        <option value='7'>7</option>
                        <option value='8'>8</option>
                        <option value='9'>9</option>
                        <option value='10'>10</option>
                        <option value='11'>11</option>
                        <option value='12'>12</option>
                    </select>
                </div>
                                </div>
            <div class="col-md-4 mb-4">
              <div class="form-outline">
                <label class="form-label" for="section">Section</label>
                <input type="text" name="section" class="form-control border-dark" placeholder="Like: A, B, SCIENCE, ARTS" required />
                <label class="form-label heading" for="section">Don't leave it blank if no section then put A</label>
              </div>
              <button type="button" class="delete-student btn btn-danger btn-sm position-absolute" style="right: 0; top: 0;">X</button>
            </div>
          </div>
          <div class="form-check d-flex justify-content-center mb-4">
            <button type="submit" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-block mb-4">
                Submit
            </button>
        </div>
        </div>
        </form>
        `;

        // Append the new section to the container
        document.getElementById("newSectionsContainer").insertAdjacentHTML('beforeend', newSection);

        // Add event listener to remove the section
        document.querySelectorAll('.delete-student').forEach(button => {
            button.addEventListener('click', function () {
                this.closest('.student-row').remove();
            });
        });
    });
</script>


<!--present class details-->

<section>
    <div class="container  text-center text-lg-start gx-lg-5">
        <div class=" card mb-5 px-5 mb-lg-0 text-center overflow-auto" style="z-index: 10">
            <div class="heading">
                <h2 class="my-5 display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 55%)">All the class present</h2>
            </div>
            <table class="table table-striped">

                <tr>
                    <th scope="col">Sl. no.</th>
                    <th scope="col" style="width:25%;">Session</th>
                    <th scope="col" style="width:25%;">Class</th>
                    <th scope="col" style="width:25%;">Section</th>
                    <th scope="col" style="width:15%;"></th>
                </tr>


                <?php
                    // Assuming you have already established a database connection in $conn
                    $className = $_SESSION['id'] . "_class_details";
                    $sql3 = "SELECT `id`, `class_no`, `section`, `session`
                    FROM `$className` 
                    WHERE 1 
                    ORDER BY `session` DESC, `class_no` ASC, `section`ASC";
                    $result3 = $conn->query($sql3);

                    if ($result3->num_rows > 0) {
                        $count = 1; // Initialize count
                    
                        // Output data of each row
                        while ($row3 = $result3->fetch_assoc()) {
                            $q = $row3['id'];
                            $class = $row3['session'] . "-" . $row3['class_no'] . "-" . strtoupper($row3['section']);
                            echo "<tr>";
                            echo "<th scope='row'>" . $count . "</th>"; // Display count
                            echo "<td>" . $row3['session'] . "</td>";
                            echo "<td>" . $row3['class_no'] . "</td>";
                            echo "<td>" . $row3['section'] . "</td>";
                            echo "
                                <td class='end'>
                                    <form action='add_subject.php' method='POST'>
                                        <input type='hidden' name='id' value='" . $row3['id'] . "'>
                                        <input type='hidden' name='session' value='" . $row3['session'] . "'>
                                        <input type='hidden' name='class_no' value='" . $row3['class_no'] . "'>
                                        <input type='hidden' name='section' value='" . strtoupper($row3['section']) . "'>
                                        <button type='submit' class='btn btn-primary justify-content-md-end'>Enter class</button>
                                    </form>
                                </td>
                            ";

                            echo "</tr>";

                            $count++; // Increment count
                        }
                    } else {
                        echo "<tr><td colspan='4'>No records found</td></tr>";
                    }
                    ?>
            </table>
        </div>
    </div>
</section>






<?php
include "footer.php";
?>