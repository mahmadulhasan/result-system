if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db_connection.php'; // Adjust your DB connection path

    $s_id = $_POST['s_id'];
    $subject_table_name = $_POST['subject_table_name'];

    // Write the delete query
    $sql = "DELETE FROM `$subject_table_name` WHERE `id` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $s_id);

    if ($stmt->execute()) {
        echo 'success';
    } else {
        echo 'error';
    }

}
