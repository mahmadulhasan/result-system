<?php
include_once "../../config.php";
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include PhpSpreadsheet autoloader
require 'vendor/autoload.php'; // PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;




// Check if session variable 'id' exists
if (!isset($_SESSION['id'])) {
    die("Session 'id' not set. Please log in.");
}

// Ensure no output has been sent before this point
if (ob_get_length()) {
    ob_end_clean(); // Clean buffer if any
}

// Get required parameters
$id = $_SESSION['id'];
$c_id = $_GET['q'] ?? null;
$session = $_GET['session'] ?? null;
$class_no = $_GET['class_no'] ?? null;
$section = $_GET['section'] ?? null;

// Check if essential parameters are provided
if (!$c_id || !$session || !$class_no || !$section) {
    die("Missing required parameters.");
}

// Construct subject table name
$subject_table = $id . '_' . $session . '_' . $class_no . '_' . $section . '_subject';

// Fetch subjects
$subjects = [];
$subject_query = "SELECT `subject_name` FROM `$subject_table`";
$subject_result = $conn->query($subject_query);

if (!$subject_result) {
    die("Error fetching subjects: " . $conn->error);
}

if ($subject_result->num_rows > 0) {
    while ($row = $subject_result->fetch_assoc()) {
        $subjects[] = $row['subject_name'];
    }
} else {
    die("No subjects found in the table.");
}

// Fetch students
$students = [];
$student_query = "SELECT `id`, `result_id`, `roll_no`, `name`, `gurdian_name`, `date_of_birth`, `school_id`, `class_id` 
                  FROM `student_details` 
                  WHERE `school_id`= '$id' AND `class_id`= '$c_id'";
$student_result = $conn->query($student_query);

if (!$student_result) {
    die("Error fetching students: " . $conn->error);
}

if ($student_result->num_rows > 0) {
    while ($row = $student_result->fetch_assoc()) {
        $students[] = $row;
    }
} else {
    die("No students found for the selected class.");
}

// Create a new Spreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set the header row
$headers = ['Roll No', 'Student ID', 'Name']; //, 'Guardian Name', 'Date of Birth'];
$headers = array_merge($headers, $subjects); // Add subjects to the header row
$sheet->fromArray($headers, NULL, 'A1'); // Output headers in the first row

// Add student data to the sheet
$rowIndex = 2; // Start adding data from the second row
foreach ($students as $student) {
    $sheet->setCellValue('A' . $rowIndex, $student['roll_no']); // Roll No
    $sheet->setCellValue('B' . $rowIndex, $student['result_id']); // Student ID
    $sheet->setCellValue('C' . $rowIndex, $student['name']); // Name
    // $sheet->setCellValue('D' . $rowIndex, $student['gurdian_name']); // Guardian Name
    // $sheet->setCellValue('E' . $rowIndex, $student['date_of_birth']); // Date of Birth

    // Leave the rest of the subjects empty (can be filled later if needed)
    $rowIndex++;
}

// Prepare the headers for Excel file download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="student_subject_data.xlsx"');
header('Cache-Control: max-age=0');
header('Pragma: public'); // To prevent caching issues
header('Expires: 0'); // No caching

// Output the Excel file for download
$writer = new Xlsx($spreadsheet);
$writer->save('php://output'); // Directly output the file content

exit; // Exit to prevent further output
?>