<?php
include_once "../../config.php";
include_once "header.php";

// Check if the user is not logged in
if ($_SESSION['login'] != true) {
    header("location:../index.php");
    exit;
}
if(isset($_GET['q'])){
    $_SESSION['cid']= $_GET['q'];
}
if (isset($_POST['exam_name'])) {
    $exam_name = $_POST['exam_name'];
    $session = $_GET['S'];
    $class = $_GET['c'];
    $section = $_GET['s'];
    $id = $_GET['q'];

    $result_table_name = $_SESSION['id'] . "_" . $session . "_" . $class . "_" . $section . "_" . $exam_name . "_" . "result";
    $subject_table_name = $_SESSION['id'] . "_" . $session . "_" . $class . "_" . $section . "_" . $exam_name . "_" . "subject";

    $insert_table = $_SESSION['id'] . "_resulttablename";

    $exam_name = strtoupper($exam_name);

    $sql3 = "SELECT * FROM `$insert_table` WHERE `exam_name`= '$exam_name' AND `class_id`='$id' ";
    $result3 = $conn->query($sql3);

    if ($result3->num_rows > 0) {
        echo "<script>alert('Exam already present');
        window.history.back();</script>";

        exit;
    }

    $sql2 = "INSERT INTO `$insert_table`(`id`, `result_table_name`, `subject_table_name`, `exam_name`, `class_id`) VALUES ('','$result_table_name','$subject_table_name','$exam_name','$id')";

    $result2 = $conn->query($sql2);
    if ($result2) {
        echo "<script>alert('Exam name added Successfully');</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }




}

?>




<style>
    section {
        padding: 0 !important;
    }

    .border {
        border-left: 1px solid grey;
    }
</style>
<section>
    <style>
        .heading {
            font-size: 0.8rem;
            color: red;
        }

        .card {
            border: none !important;
        }

        .border1 {
            border: 1px solid gray !important;
            color: gray !important;
        }
    </style>

    <div class="container  pt-5  text-center text-lg-start my-5">
        <div class="row">

            <div class="col-lg-6 col-lg mb-5 mb-lg-0 position-relative">

                <div class="card card2">
                    <div class="card-body  py-3 ">
                        <div>
                            <h2 class=" display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 55%)"> Already present
                                Exams
                            </h2>
                        </div>
                        <div>
                            <?php
                            if (isset($_GET['q'])) {
                                $id = $_GET['q'];
                                $session = $_GET['S'];
                                $class = $_GET['c'];
                                $section = $_GET['s'];
                                

                                echo '<h2 class="display-7 fw-bold ls-tight border px-5" >Session: ' . $session . '<br> Class Level: ' . $class . ', Section: ' . $section . '</h2>';

                                $resultTableName = $_SESSION['id'] . "_resulttablename";
                                $sql = "SELECT * FROM `$resultTableName` WHERE `class_id`='$id'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $rid = $row['id'];
                                        $en = $row['exam_name'];
                                        $subject_table_name2 = $row['subject_table_name'];
                                        $result_table_name2 = $row['result_table_name'];
                                        ?>
                                    
                                        <form action="add_subject.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="q" value="<?php echo htmlspecialchars($rid); ?>">
                                            <input type="hidden" name="exam" value="<?php echo htmlspecialchars($en); ?>">
                                            <input type="hidden" name="c" value="<?php echo htmlspecialchars($subject_table_name2); ?>">
                                            <input type="hidden" name="rtn" value="<?php echo htmlspecialchars($result_table_name2); ?>">
                                            <button type="submit" class="btn btn-lg btn-outline-info btn-block mb-4 me-2"><?php echo htmlspecialchars($en); ?></button>
                                        </form>
                                    
                                        <?php
                                    }
                                    
                                } else {
                                    echo "No exams found for this class.";
                                }

                            }
                            ?>
                        </div>


                    </div>
                </div>
            </div>

            <!-- -------Add New Exam Part----------- -->
            <div class="container col-lg-6  border1 text-center text-lg-start">
                <div class="col-lg mb-5 mb-lg-0 position-relative">
                    <div class="card bg-glass">
                        <div class="card-body ">
                            <div>
                                <h2 class=" display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 55%)">Add New Exam
                                </h2>
                            </div>

                            <form action="" method="POST">
                                <div data-mdb-input-init class="form-outline mb-4">
                                    <label class="form-label" for="form3Example4">Exam Name</label>
                                    <input type="text" name="exam_name" id="exam_name" class="form-control" required />
                                    <span class="heading ">(Like: Unit Test 1/ Final Exam)</span>
                                </div>
                                <div data-mdb-input-init class="form-outline mb-4">
                                    <button type="submit" class="btn btn-lg btn-outline-danger btn-block mb-4">
                                        Create Exam
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>



<?php
include "footer.php";
?>