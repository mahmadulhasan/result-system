<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];
?>



<section class="container text-center">
    <div class="card py-5" style="max-height:650px; border:none !important">
        <h5 class="card-header bg-info">Select result to edit</h5>
        <div class="card-body overflow-auto">
            <?php
            $query = "SELECT * FROM `published_result` WHERE `school_id`= '$id' ORDER BY `id` DESC LIMIT 200";
            $res = $conn->query($query);

            if ($res->num_rows > 0) {
                echo '<table class="table table-bordered text-center">';
                echo '<thead class="table-dark">';
                echo '<tr>';
                echo '<th>Session</th>';
                echo '<th>Class</th>';
                echo '<th>Section</th>';
                echo '<th>Exam Name</th>';
                echo '<th>Select</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                while ($row = $res->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['session'] . '</td>';
                    echo '<td>' . $row['class'] . '</td>';
                    echo '<td>' . $row['section'] . '</td>';
                    echo '<td>' . $row['exam_name'] . '</td>';
                    echo '<td>';
                    echo '<form method="POST" action="">';
                    echo '<input type="hidden" name="id" value="' . $row['id'] . '">';
                    echo '<input type="hidden" name="school_name" value="' . $row['school_name'] . '">';
                    echo '<input type="hidden" name="school_add" value="' . $row['school_add'] . '">';
                    echo '<input type="hidden" name="school_pin" value="' . $row['school_pin'] . '">';
                    echo '<input type="hidden" name="class" value="' . $row['class'] . '">';
                    echo '<input type="hidden" name="section" value="' . $row['section'] . '">';
                    echo '<input type="hidden" name="session" value="' . $row['session'] . '">';
                    echo '<input type="hidden" name="exam_name" value="' . $row['exam_name'] . '">';
                    echo '<button type="submit" class="btn btn-primary">Select</button>';
                    echo '</form>';
                    echo '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
            } else {
                echo "No results found.";
            }
            ?>
        </div>
    </div>
</section>




<?php
include "footer.php";
?>