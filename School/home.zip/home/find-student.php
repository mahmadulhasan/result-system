<?php
include_once "../../config.php";
include_once "header.php";

// Check if the user is not logged in
if ($_SESSION['login'] != true) {
    header("location:../index.php");
    exit;
}

$id = $_SESSION['id'];
$class_table = $id."_class_details";

?>
    <style>
        /* Adjust the height of the container for better centering */
        .centered-container {
            margin: auto; /* Centers the container */
            display: flex; /* Use flexbox for alignment */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            height: 100px; /* Set a fixed height for vertical centering if needed */
        }
        i{
            font-size:1.5rem !important;
        }
        button{
            color:white !important;
            item-align: center;
        }
        .input-group{
            border-radius:10px;
        }
    </style>
</head>
<body>

<div class="container search-container">
    <div class="row justify-content-center"> <!-- Center horizontally in the row -->
        <div class="col-md-8"> <!-- Set the width of the search form -->
            <div class="input-group">
                
                <span>Enter Student Id or Student Name or Gurdian Name to find the student data </span>
                
                <form class="w-100" method="post"  action=""> <!-- Use full width -->
                    <div class="input-group border border-dark">
                        <input class="form-control" type="search" name="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                            <button class="btn btn-outline-success px-5 bg-primary" type="submit"><i class='bx bx-search-alt-2' style='color:#f9f7f7'  ></i> &nbsp; Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<section>
    <?php
    if(isset($_POST['search'])){
        $search = strtoupper(trim($_POST['search']));
        $sql = "SELECT 
                    s.result_id,s.roll_no, s.name, s.gurdian_name, s.date_of_birth, c.class_no, c.section, c.session
                FROM 
                    student_details s
                INNER JOIN 
                    `$class_table` c
                ON 
                    s.class_id = c.id
                WHERE 
                    (s.result_id = '$search' 
                    OR s.name = '$search' 
                    OR s.gurdian_name = '$search')
                    AND s.school_id = '$id';
                ";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<section class="card mx-5 px-5 mb-2 overflow-auto">';
                echo '<table class="table">';
        
                // Student ID
                echo '<tr><td colspan="3">Student ID: <strong>' . $row['result_id'] . '</strong> &nbsp;| &nbsp; Roll no: <strong>' . $row['roll_no'] . '</strong></td></tr>';
        
                // First row with Name, Guardian Name, Date of Birth
                echo '<tr>';
                echo "<td> Name: <strong>" . $row['name'] . "</strong></td>";
                echo "<td> Guardian Name: <strong>" . $row['gurdian_name'] . "</strong></td>";
                echo "<td> Date of Birth: <strong>" . $row['date_of_birth'] . "</strong></td>";
                echo '</tr>';
        
                // Second row with Class No, Section, Session
                echo '<tr>';
                echo "<td> Class No: <strong>" . $row['class_no'] . "</strong></td>";
                echo "<td> Section: <strong>" . $row['section'] . "</strong></td>";
                echo "<td> Session: <strong>" . $row['session'] . "</strong></td>";
                echo '</tr>';
        
                echo '</table>';
                echo "</section>";
            }
        } else {
            echo "No records found.";
        }
    }else{
                echo '<section class="card mx-5 px-5 overflow-auto">';
                echo '<table class="table table-bordered text-center">';
                echo '<thead class="table-dark">';
                echo '<tr>';
                echo '<th>Result ID</th>';
                echo '<th>Roll No</th>';
                echo '<th>Student Name</th>';
                echo '<th>Guardian Name</th>';
                echo '<th>Date of Birth</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';
                
                
            $query = "SELECT `id`, `result_id`,`roll_no`, `name`, `gurdian_name`, `date_of_birth`, `school_id` 
                      FROM `student_details` 
                      WHERE `school_id` = '$id' 
                      ORDER BY `result_id` DESC";

            $res = $conn->query($query);

            if ($res->num_rows > 0) {
                

                while ($row = $res->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['result_id'] . '</td>';
                    echo '<td>' . $row['roll_no'] . '</td>';
                    echo '<td>' . $row['name'] . '</td>';
                    echo '<td>' . $row['gurdian_name'] . '</td>';
                    echo '<td>' . $row['date_of_birth'] . '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
                echo "</section>";
            } else {
                echo "No student details found.";
            }
    }
    ?>
</section>


<?php
include "footer.php";
?>