<?php
include_once "../../config.php";

if(isset($_POST['class_no']) && isset($_POST['session']) && isset($_SESSION['id'])) {
    // Sanitize inputs to prevent SQL injection
    $class_no = mysqli_real_escape_string($conn, $_POST['class_no']);
    $session = mysqli_real_escape_string($conn, $_POST['session']);
    $table = mysqli_real_escape_string($conn, $_SESSION['id'] . "_class_details");

    // Query to fetch distinct sections based on class_no and session
    $query = "SELECT DISTINCT `section` FROM `$table` WHERE `class_no` = '$class_no' AND `session` = '$session'";
    $result = mysqli_query($conn, $query);

    if($result) {
        while($row = mysqli_fetch_assoc($result)) {
            echo '<option value="'.htmlspecialchars($row['section']).'">'.htmlspecialchars($row['section']).'</option>';
        }
    } else {
        // Handle query failure
        echo '<option value="">Error fetching sections</option>';
    }
} else {
    echo '<option value="">Invalid request</option>';
}
?>
