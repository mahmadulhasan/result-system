<?php
include_once "../../config.php";

if (isset($_POST['class_no']) && isset($_SESSION['id'])) {
    // Sanitize input to prevent SQL injection
    $class_no = mysqli_real_escape_string($conn, $_POST['class_no']);
    $table = mysqli_real_escape_string($conn, $_SESSION['id'] . "_class_details");

    // Query to fetch distinct sessions based on class_no
    $query = "SELECT DISTINCT `session` FROM `$table` WHERE `class_no` = '$class_no'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Use htmlspecialchars to escape any special characters for security (XSS prevention)
            echo '<option value="' . htmlspecialchars($row['session']) . '">' . htmlspecialchars($row['session']) . '</option>';
        }
    } else {
        // Handle query failure
        echo '<option value="">Error fetching sessions</option>';
    }
} else {
    echo '<option value="">Invalid request</option>';
}
?>
