<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School | Result</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .nav-link:hover {
            background: #4499f4 !important;
            border-radius: 0 !important;
        }
        .a {
            color: white !important;
        }
        .nav-item {
            display: inline-block;
            white-space: nowrap;
        }
        .active-link {
            font-weight: 800;
            border-bottom:2px solid white;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-primary justify-content-between pe-5 ps-5">
            <div class="container-fluid">
                <a class="navbar-brand" href="../../index.php"><img src="../../upload/image/logo.png" style="height:50px;width:150px; background:white; padding:10px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse ms-auto end-0 justify-content-between" id="navbarNav">
                <ul class="navbar-nav pe-5">
                    <?php 
                        $current_page = basename($_SERVER['PHP_SELF']);
                    ?>
                    <li class="nav-item pe-3">
                        <a class="nav-link a <?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>" href="index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown pe-3">
                        <a class="nav-link dropdown-toggle <?php echo ($current_page == 'add-result-form.php' || $current_page == 'recent-upload.php') ? 'active-link' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color:white;">
                            Result
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="add-result-form.php">Add Result</a></li>
                            <li><a class="dropdown-item" href="recent-upload.php">Recent Upload</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown pe-3">
                        <a class="nav-link dropdown-toggle <?php echo ($current_page == 'add-student.php' || $current_page == 'find-student.php' || $current_page == 'recent-student-added.php') ? 'active-link' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color:white;">
                            Student
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="add-student.php">Add Student</a></li>
                            <li><a class="dropdown-item" href="find-student.php">Find Student</a></li>
                            <li><a class="dropdown-item" href="recent-student-added.php">Recent Student Added</a></li>
                        </ul>
                    </li>
                    <li class="nav-item pe-3">
                        <a class="nav-link a <?php echo ($current_page == 'class.php') ? 'active-link' : ''; ?>" href="class.php">Class</a>
                    </li>
                </ul>

                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <a class="dropdown-toggle d-flex align-items-center hidden-arrow a" href="#"
                            id="navbarDropdownMenuAvatar" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php print $_SESSION['sname']; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                            <li>
                                <a class="dropdown-item" href="logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div style="margin-top: 5rem;"></div>
</body>
</html>
