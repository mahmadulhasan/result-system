<?php
include_once "../../config.php";
include_once "header.php";
$id = $_SESSION['id'];


// Check if the user is not logged in
if ($_SESSION['login'] != true) {
    header("location:../index.php");
    exit;
}


?>

<section class="container mt-5 text-center">
    <h1 class="heading display-5 fw-bold" style="color: hsl(218, 51%, 55%)">Notice</h1>
    <div class="row d-flex justify-content-center flex-wrap">
        <?php
        // Fetch notices with active status for the home page
        $sql = "SELECT `id`, `heading`, `body`, `status`, `page`, `date` FROM `notice` WHERE `page` = 'school' AND `status` = 'active' ORDER BY `id` DESC LIMIT 5";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '
                <div class="col-md-3 d-flex align-items-stretch mb-4">
                    <div class="card w-100 h-100">
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item text-start"><p class="card-text"><small class="text-muted">' . htmlspecialchars($row['date']) . '</small></p></li>
                                <li class="list-group-item">
                                    <h5 class="card-title">' . htmlspecialchars($row['heading']) . '</h5>
                                    <p class="card-text">' . htmlspecialchars($row['body']) . '</p>
                                </li>
                             </ul>
                        </div>
                    </div>
                </div>';
            }
        } else {
            // Display a card if no notices are found
            echo '
            <div class="col-md-3 d-flex align-items-stretch mb-4">
                <div class="card w-100 h-100">
                    <div class="card-body">
                        <p class="card-text">No active notices available.</p>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</section>

<section class="background-radial-gradient overflow-hidden">

    <div class="container text-center text-lg-start ">
        <div class="  my-3 ">
            <div class="  mb-5 mb-lg-0 position-relative">
                <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
                <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

                <div class="card bg-glass">
                    <div class="card-body px-4 py-5 px-md-5">
                        <h1 class="  fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">

                            <span style="color: hsl(218, 81%, 75%)">Pending publishing result</span>
                        </h1>
                        <div class="mb-4 opacity-70 overflow-auto" style="color: hsl(218, 81%, 85%)">
                            <table class="table text-center">
                              <thead class="table-dark">
                                  <tr>
                                      <th scope="col">Sl no.</th>
                                      <th scope="col">Publish date</th>
                                      <th scope="col">Publish time</th>
                                      <th scope="col">Session</th>
                                      <th scope="col">Class</th>
                                      <th scope="col">Section</th>
                                      <th scope="col">Exam name</th>
                                    </tr>
                              </thead>
                              <tbody>
                                   <?php
                                    // Query to fetch data
                                    $query = "SELECT * FROM `published_result` 
                                              WHERE `school_id`= '$id' 
                                              ORDER BY `id` DESC";
                                    $res = $conn->query($query);
                                    
                                    if ($res->num_rows > 0) {
                                        $sl_no = 1; // Initialize serial number
                                    
                                        // Get the current date and time
                                        $currentDate = new DateTime();
                                        
                                        while ($row = $res->fetch_assoc()) {
                                            // Convert publish date and time to DateTime objects
                                            $publishDateTime = new DateTime($row['publish_date'] . ' ' . $row['publish_time']);
                                            
                                            // Check if current date and time is greater than or equal to publish date and time
                                            if ($currentDate < $publishDateTime) {
                                                echo "<tr>";
                                                echo "<td>" . $sl_no++ . "</td>"; // Sl no.
                                                
                                                // Convert the publish_date into a DateTime object
                                                $publishDate = new DateTime($row['publish_date']);
                                                // Format it as d-m-Y (day-month-year)
                                                echo "<td>" . $publishDate->format('d-m-Y') . "</td>"; // Publish date
                                                
                                                echo "<td>" . $row['publish_time'] . "</td>"; // Publish time
                                                echo "<td>" . $row['session'] . "</td>"; // Session
                                                echo "<td>" . $row['class'] . "</td>"; // Class
                                                echo "<td>" . strtoupper($row['section']) . "</td>"; // Section (in uppercase)
                                                echo "<td>" . $row['exam_name'] . "</td>"; // Exam name
                                                echo "</tr>";
                                            }
                                        }
                                    } else {
                                        echo "<tr><td colspan='7'>No results found.</td></tr>";
                                    }
                                    ?>
                              </tbody>
                            </table>

                        </div>


                    </div>
                </div>
            </div>

            <div class=" my-5 mb-lg-0 position-relative">
                <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
                <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

                <div class="card bg-glass">
                    <div class="card-body px-4 py-5 px-md-5">
                        <h1 class=" fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">

                            <span style="color: hsl(218, 81%, 75%)">Published result</span>
                        </h1>
                        <div class="mb-4 opacity-70 overflow-auto" style="color: hsl(218, 81%, 85%)">
                            <table class="table text-center">
                              <thead class="table-dark">
                                  <tr>
                                      <th scope="col">Sl no.</th>
                                      <th scope="col">Publish date</th>
                                      <th scope="col">Publish time</th>
                                      <th scope="col">Session</th>
                                      <th scope="col">Class</th>
                                      <th scope="col">Section</th>
                                      <th scope="col">Exam name</th>
                                    </tr>
                              </thead>
                              <tbody>
                                     <?php
                                    // Query to fetch data
                                    $query = "SELECT * FROM `published_result` 
                                              WHERE `school_id`= '$id' 
                                              ORDER BY `id` DESC";
                                    $res = $conn->query($query);
                                    
                                    
                                    if ($res->num_rows > 0) {
                                        $sl_no = 1; // Initialize serial number
                                    
                                        // Get the current date and time
                                        $currentDate = new DateTime();
                                        
                                        while ($row = $res->fetch_assoc()) {
                                            // Convert publish date and time to DateTime objects
                                            $publishDateTime = new DateTime($row['publish_date'] . ' ' . $row['publish_time']);
                                            
                                            // Check if current date and time is greater than or equal to publish date and time
                                            if ($currentDate >= $publishDateTime) {
                                                echo "<tr>";
                                                echo "<td>" . $sl_no++ . "</td>"; // Sl no.
                                                
                                                // Convert the publish_date into a DateTime object
                                                $publishDate = new DateTime($row['publish_date']);
                                                // Format it as d-m-Y (day-month-year)
                                                echo "<td>" . $publishDate->format('d-m-Y') . "</td>"; // Publish date
                                                
                                                echo "<td>" . $row['publish_time'] . "</td>"; // Publish time
                                                echo "<td>" . $row['session'] . "</td>"; // Session
                                                echo "<td>" . $row['class'] . "</td>"; // Class
                                                echo "<td>" . strtoupper($row['section']) . "</td>"; // Section (in uppercase)
                                                echo "<td>" . $row['exam_name'] . "</td>"; // Exam name
                                                echo "</tr>";
                                            }
                                        }
                                    } else {
                                        echo "<tr><td colspan='9'>No results found.</td></tr>";
                                    }
                                    ?>
                              </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<?php
include "footer.php";
?>