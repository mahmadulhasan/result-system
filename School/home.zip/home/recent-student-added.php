<?php
include "../../config.php";
include "header.php";
$id = $_SESSION['id'];

?>

<section class="container text-center">
    <div class="card " style=" border:none !important">
        <h5 class="card-header bg-info">Student Details</h5>
        <div class="card-body overflow-auto">
            <?php
            
            echo '<table class="table table-bordered text-center">';
                echo '<thead class="table-dark">';
                echo '<tr>';
                echo '<th>Result ID</th>';
                echo '<th>Student Name</th>';
                echo '<th>Guardian Name</th>';
                echo '<th>Date of Birth</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';
                
                
            $query = "SELECT `id`, `result_id`, `name`, `gurdian_name`, `date_of_birth`, `school_id` 
                      FROM `student_details` 
                      WHERE `school_id` = '$id' 
                      ORDER BY `id` DESC";

            $res = $conn->query($query);

            if ($res->num_rows > 0) {
                

                while ($row = $res->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['result_id'] . '</td>';
                    echo '<td>' . $row['name'] . '</td>';
                    echo '<td>' . $row['gurdian_name'] . '</td>';
                    echo '<td>' . $row['date_of_birth'] . '</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
            } else {
                echo "No student details found.";
            }
            ?>
        </div>
    </div>
</section>





<?php
include "footer.php";
?>