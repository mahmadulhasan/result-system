<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];
?>

<div class="card bg-glass mx-5">
    <div class="card-body px-4 py-5 px-md-5">
        <h1 class="fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">
            <span style="color: hsl(218, 81%, 75%)">Uploaded Result Data</span>
        </h1>
        <div class="mb-4 opacity-70 overflow-auto" style="color: hsl(218, 81%, 85%)">
            <table class="table text-center">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Sl no.</th>
                        <th scope="col">Upload date</th>
                        <th scope="col">Publish date</th>
                        <th scope="col">Publish time</th>
                        <th scope="col">Session</th>
                        <th scope="col">Class</th>
                        <th scope="col">Section</th>
                        <th scope="col">Exam name</th>
                        <th scope="col">See result</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query to fetch data
                    $query = "SELECT * FROM `published_result` 
                              WHERE `school_id`= '$id' 
                              ORDER BY `id` DESC";
                    $res = $conn->query($query);
                    
                    if ($res->num_rows > 0) {
                        $sl_no = 1; // Initialize serial number
                        while ($row = $res->fetch_assoc()) {
                            echo "<tr>";
                            echo "<form method='POST' action='view-result.php'>";
                            echo "<td>" . $sl_no++ . "</td>"; // Sl no.
                            
                            // Convert the upload_date into a DateTime object
                            $uploadDate = new DateTime($row['upload_date']);
                            // Format it as d-m-Y (day-month-year)
                            echo "<td>" . $uploadDate->format('d-m-Y') . "</td>"; // Upload date
                            
                            // Convert the publish_date into a DateTime object
                            $publishDate = new DateTime($row['publish_date']);
                            // Format it as d-m-Y (day-month-year)
                            echo "<td>" . $publishDate->format('d-m-Y') . "</td>"; // Publish date
                            
                            echo "<td>" . htmlspecialchars($row['publish_time']) . "</td>"; // Publish time
                            echo "<td>" . htmlspecialchars($row['session']) . "</td>"; // Session
                            echo "<td>" . htmlspecialchars($row['class']) . "</td>"; // Class
                            echo "<td>" . strtoupper(htmlspecialchars($row['section'])) . "</td>"; // Section (in uppercase)
                            echo "<td>" . htmlspecialchars($row['exam_name']) . "</td>"; // Exam name
                            
                            // Hidden fields for result_table_name and subject_table_name
                            echo "<input type='hidden' name='result_table_name' value='" . htmlspecialchars($row['result_table_name']) . "'>";
                            echo "<input type='hidden' name='subject_table_name' value='" . htmlspecialchars($row['subject_table_name']) . "'>";
                            echo "<input type='hidden' name='class' value='" . htmlspecialchars($row['class']) . "'>";
                            echo "<input type='hidden' name='session' value='" . htmlspecialchars($row['session']) . "'>";
                            echo "<input type='hidden' name='section' value='" . htmlspecialchars($row['section']) . "'>";
                            echo "<input type='hidden' name='exam_name' value='" . htmlspecialchars($row['exam_name']) . "'>";
                            
                            // Submit button to see the result
                            echo "<td><button type='submit' class='btn btn-primary'>Print result</button></td>";
                            
                            echo "</form>"; // Close form here
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9'>No results found.</td></tr>"; // Adjust colspan to match the number of columns
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>




<?php
include "footer.php";
?>