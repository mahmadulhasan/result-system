<?php
include_once "../../config.php";
include "header.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include necessary libraries
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

$id = $_SESSION['id'];

// Fetch school details from the database
$sql1 = "SELECT id, school_name, email, phone_no, state, pin_code, address, password 
         FROM school_details WHERE id = '$id'";
$result1 = $conn->query($sql1);
$row1 = $result1->fetch_assoc();

// Store school details
$school_name = $row1['school_name'];
$state = $row1['state'];
$pin_code = $row1['pin_code'];
$address = $row1['address'];

$result_table_name = "";
$subject_table_name = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $session = $_POST['session'];
    $class_no = $_POST['class_no'];
    $section = $_POST['section'];
    $exam_name = $_POST['exam_name'];
    $publish_date = $_POST['publish_date'];
    $publish_time = $_POST['publish_time'];
    $upload_date = date('Y-m-d'); // Format: YYYY-MM-DD
    $full_marks = $_POST['full_marks']; // Single value
    $pass_marks = $_POST['pass_marks']; // Single value

    // Generate table names for result and subject tables
    $result_table_name = $id . "_" . $session . "_" . $class_no . "_" . $section . "_" . $exam_name . "_result";
    $subject_table_name = $id . "_" . $session . "_" . $class_no . "_" . $section . "_subject";
    $resulttablename = $id . "_resulttablename";

    // Check if the tables already exist for this session, class, section, and exam
    $sql2 = "SELECT result_table_name, subject_table_name, exam_name, class_id 
             FROM $resulttablename 
             WHERE LOWER(result_table_name) = LOWER('$result_table_name') 
             AND LOWER(subject_table_name) = LOWER('$subject_table_name')";
    $result2 = $conn->query($sql2);

    if ($result2->num_rows > 0) {
        echo "<script>alert('The exam for this class and section is already present. You can find it in the class.');</script>";
        echo "<script>window.location.href = 'add-class.php';</script>";
        exit;
    }

    // Check if the result table exists, if not, create it
    $checkTableSql = "SHOW TABLES LIKE '$result_table_name'";
    $result = $conn->query($checkTableSql);

    if ($result->num_rows == 0) {
        // Create result table
        $sqlCreate = "CREATE TABLE `$result_table_name` (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            Roll_no VARCHAR(255),
            student_id VARCHAR(255),
            student_name VARCHAR(255),
            full_mark VARCHAR(255),
            pass_mark VARCHAR(255),
            remark VARCHAR(255))"; // Add remark column
        
        $resultTableCreateResult = $conn->query($sqlCreate);
        echo "Result table created.<br>";
        
        // Add columns for each subject
        $subjectSql = "SELECT subject_name FROM $subject_table_name WHERE 1";
        $subjectResult = $conn->query($subjectSql);
        
        if ($subjectResult->num_rows > 0) {
            while ($row = $subjectResult->fetch_assoc()) {
                $subjectName = trim($row['subject_name']);
        
                // Sanitize the subject name for use in SQL (remove spaces, etc.)
                $subjectNameSanitized = preg_replace('/[^a-zA-Z0-9_]/', '_', $subjectName);
        
                // Check if the column already exists
                $checkColumnSql = "SHOW COLUMNS FROM `$result_table_name` LIKE '$subjectNameSanitized'";
                $checkColumnResult = $conn->query($checkColumnSql);
        
                if ($checkColumnResult->num_rows == 0) {
                    // Add the column if it doesn't exist
                    $sqlsubCreate = "ALTER TABLE `$result_table_name` ADD `$subjectNameSanitized` VARCHAR(255)";
                    $resultsqlCreate = $conn->query($sqlsubCreate);
        
                    if ($resultsqlCreate) {
                        echo "Subject '$subjectName' added as column '$subjectNameSanitized'.<br>";
                    } else {
                        echo "Error adding column '$subjectNameSanitized': " . $conn->error . "<br>";
                    }
                } else {
                    echo "Column '$subjectNameSanitized' already exists.<br>";
                }
            }
        } else {
            echo "No subjects found.";
        }
    }

    // Handle file upload logic
    if (isset($_FILES['result_file']) && $_FILES['result_file']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['xls', 'csv', 'xlsx'];
        $file = $_FILES['result_file'];
        $filename = $file['name'];
        $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
        if (in_array($file_ext, $allowed)) {
            // Load the spreadsheet using PhpSpreadsheet
            $spreadsheet = IOFactory::load($file['tmp_name']);
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray();
    
            // Process each row from the spreadsheet
            foreach ($rows as $index => $row) {
                // Skip header row or any other non-data rows
                if ($index === 0 || empty($row[0])) {
                    continue;
                }
    
                $roll_no = $row[0];
                $student_id = $row[1];
                $student_name = $row[2];
    
                $subjectValues = array_slice($row, 3); // Get the subject marks
                $remark = 'Pass'; // Default remark
    
                // Determine the remark based on subject marks
                foreach ($subjectValues as $subjectValue) {
                    if (!is_numeric($subjectValue) || $subjectValue < $pass_marks || in_array(strtolower($subjectValue), ['a', 'ab'])) {
                        $remark = 'Fail';
                        break; // Exit loop if any subject fails
                    }
                }
    
                // Insert data into the result table
                $sqlInsert = "INSERT INTO `$result_table_name` (Roll_no, student_id, student_name, full_mark, pass_mark, remark";
                $values = "'$roll_no', '$student_id', '$student_name', '$full_marks', '$pass_marks', '$remark'";
    
                foreach ($subjectValues as $index => $subjectValue) {
                    // Use the correct subject name that was sanitized
                    $subjectNameSanitized = preg_replace('/[^a-zA-Z0-9_]/', '_', trim($rows[0][$index + 3])); // Assuming row[0] has subject names
                    $sqlInsert .= ", `$subjectNameSanitized`";
                    $values .= ", '" . mysqli_real_escape_string($conn, $subjectValue) . "'";
                }
    
                $sqlInsert .= ") VALUES ($values)";
    
                if ($conn->query($sqlInsert) === TRUE) {
                    echo "Data inserted successfully for Roll No: $roll_no.<br>";
                } else {
                    echo "Error inserting data for Roll No: $roll_no - " . $conn->error . "<br>";
                }
            }
    
            echo "File uploaded and data inserted successfully.<br>";
        } else {
            echo "Invalid file type. Only XLS, CSV, and XLSX files are allowed.";
        }
    } else {
        echo "Error uploading file.<br>";
    }

    // Insert into published result table
    $sql3 = "INSERT INTO published_result (id, school_id, school_name, school_add, school_state, school_pin, class, section, session, 
            exam_name, result_table_name, subject_table_name, upload_date, publish_date, publish_time)
            VALUES ('', '$id', '$school_name', '$address', '$state', '$pin_code', '$class_no', '$section', '$session', '$exam_name', 
            '$result_table_name', '$subject_table_name', '$upload_date', '$publish_date', '$publish_time')";
    if ($conn->query($sql3) === TRUE) {
        echo "Published result entry created successfully.<br>";
    } else {
        echo "Error inserting published result: " . $conn->error . "<br>";
    }
    echo "<script>alert('result uploaded successfully.'); window.location.href='recent-upload.php';</script>";
    
}

$conn->close();
?>
