<?php
ob_start();
include_once "../../config.php";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sub_num = isset($_POST['sub_num_total']) ? (int) $_POST['sub_num_total'] : 0;
    global $query;
    global $query2;
    $query = isset($_POST['query']) ? $_POST['query'] : '';
    $query2 = isset($_POST['query2']) ? $_POST['query2'] : '';

    // Create and assign dynamic variables
    for ($i = 0; $i < $sub_num; $i++) {
        $varName = 'subject' . ($i + 1);
        global $$varName;
        $$varName = isset($_POST['sub_num' . $i]) ? $_POST['sub_num' . $i] : '';
    }

    // Now print all the variables outside the loop


    global $id;
    $id = htmlspecialchars($query);
    echo 'Query parameter: ' . $id . "<br>";
} else {
    echo "<script>alert('somthing wrong with subject entry try again');</script>";
    exit;
}

$table1 = $_SESSION['id'] . "_resulttablename";
echo $table1 . "<br>";

//cheak the table name
$sql = "SELECT`subject_table_name`FROM `$table1` WHERE `id`='$id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

print $row['subject_table_name'];
global $table_name;
$table_name = $row['subject_table_name'];

// cheak if table already present
$sql4 = "SELECT COUNT(*) as count FROM information_schema.tables 
        WHERE table_schema = '$database' 
        AND table_name = '$table_name'";

$result4 = $conn->query($sql4);
$row4 = $result4->fetch_assoc();
if ($row4['count'] > 0) {
    echo "Ok to process";
} else {

    $sql2 = "CREATE TABLE `$table_name`(`id` INT(11) NOT NULL AUTO_INCREMENT,
                `subject_name` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id`)
                )";
    $result2 = $conn->query($sql2);
    if ($result2) {
        echo "Ok to process";
    } else {
        echo "<script>alert('somthing wrong with subject entry try again');</script>";
        exit;
    }

}
for ($i = 0; $i < $sub_num; $i++) {
    $varName = 'subject' . ($i + 1);
    $subjectName = strtoupper($$varName); // Get the actual subject name

    $sql3 = "INSERT INTO `$table_name` (`subject_name`) VALUES (?)";
    $result3 = $conn->prepare($sql3);
    $result3->bind_param("s", $subjectName); // Bind the actual subject name
    
    if ($result3->execute()) {
        echo 'Subject ' . ($i + 1) . ' inserted successfully: ' . htmlspecialchars($subjectName) . '<br>';
    } else {
        echo 'Failed to insert Subject ' . ($i + 1) . ': ' . htmlspecialchars($subjectName) . '<br>';
    }
    header("location:add_subject.php?qr=$table_name&q=$query&exam=$query2");
}

?>