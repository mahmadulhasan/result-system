<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];

$class_table = $_SESSION['id'] . "_class_details";
$class_id="";



// Include PHPSpreadsheet library for reading Excel files
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;




// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Print received inputs for debugging
    $class_no = $_POST['class_no'];
    $session= $_POST['session'] ;
    $section= $_POST['section'] ;
    // select class id
    $stmt = $conn->prepare("SELECT * FROM `$class_table` WHERE `class_no` = ? AND `session` = ? AND `section` = ?");
    $stmt->bind_param("iss", $class_no, $session, $section); // Assuming these are strings
    
    $stmt->execute();
    $result = $stmt->get_result(); // Get the result set from the prepared statement
    $row = $result->fetch_assoc();
    echo "<br>";
    $class_id = $row['id'];
    

    // Check if the Excel sheet upload form is submitted
    if (isset($_FILES['result_file']) && $_FILES['result_file']['error'] === UPLOAD_ERR_OK) {
        
        // File details
        $fileTmpPath = $_FILES['result_file']['tmp_name'];
        $fileName = $_FILES['result_file']['name'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        // Allowed file extensions
        $allowedfileExtensions = array('xls', 'xlsx', 'csv');

        if (in_array($fileExtension, $allowedfileExtensions)) {
            // Load the Excel file using PHPSpreadsheet
            require 'vendor/autoload.php'; // Make sure to include this line to use PHPSpreadsheet
            
            try {
                $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($fileTmpPath);
                $sheet = $spreadsheet->getActiveSheet();
            } catch (\PhpOffice\PhpSpreadsheet\Reader\Exception $e) {
                die('Error loading file: ' . $e->getMessage());
            }

            // Prepare to read data from the spreadsheet, skipping the first row
            $data = [];
            foreach ($sheet->getRowIterator() as $row) {
                $rowIndex = $row->getRowIndex();
                // Skip the first row (column headers)
                if ($rowIndex == 1) continue;

                // Read the row data into an array
                $rowData = $sheet->rangeToArray('A' . $rowIndex . ':' . $sheet->getHighestColumn() . $rowIndex, NULL, TRUE, FALSE);
                $data[] = $rowData[0]; // Store row data
            }

            // Debug: print the data from the Excel sheet
            foreach ($data as $student) {
                $roll = strtoupper(trim($student[0]));
                $name = strtoupper(trim($student[1]));
                $guardian_name = strtoupper(trim($student[2]));
                $dob = trim($student[3]);
                $dob = date("Y-m-d", ($dob - 25569) * 86400);

                echo "ROll: $roll, Name: $name, Guardian: $guardian, DOB: $dob<br>";

                // Insert the data into the database
                $stmt2 = "INSERT INTO `student_details`(`id`, `result_id`, `roll_no`, `name`, `gurdian_name`, `date_of_birth`, `school_id`, `class_id`) VALUES ('','','$roll','$name','$guardian_name','$dob','$id','$class_id')";
                $result2 = $conn->query($stmt2);
                if ($result2) {
                    // Get the last inserted id to calculate result_id
                    $last_id = $conn->insert_id; // Get the last inserted id
                    $result_id = $last_id + 15000; // Calculate result_id
        
                    // Update the record with result_id
                    $update_sql = "UPDATE student_details SET result_id = ? WHERE id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    if ($update_stmt === false) {
                        echo "<script>alert('SQL update prepare statement failed.'); window.location.href='add-student.php';</script>";
                        exit;
                    }
                    $update_stmt->bind_param("ii", $result_id, $last_id);
                    $update_stmt->execute();
                    echo "Record for $name inserted successfully.<br>";
                } else {
                    echo "Error inserting record for $name: <br>";
                }
            }
            echo "<script>alert('Student records have been successfully added.'); window.location.href='recent-student-added.php';</script>";
        } else {
            echo "<script>alert('Invalid file type. Please upload an Excel file.'); window.location.href='add-student.php';</script>";
        }
    }
}





// 2nd form--------

     // Check if the manual student entry form is submitted
    if (isset($_POST['name'])) {
        
        $class_no2 = $_POST['class_no2'];
        $session2 = $_POST['session2'];
        $section2 = $_POST['section2'];
        
        // select class id
        $stmt = $conn->prepare("SELECT * FROM `$class_table` WHERE `class_no` = ? AND `session` = ? AND `section` = ?");
        $stmt->bind_param("iss", $class_no2, $session2, $section2); // Assuming these are strings
        
        $stmt->execute();
        $result = $stmt->get_result(); // Get the result set from the prepared statement
        $row = $result->fetch_assoc();
        echo "<br>";
        $class_id = $row['id'];
        echo "<br>";
        
        
        $roll = $_POST['roll_no'];
        $names = $_POST['name'];
        $guardian_names = $_POST['guardian_name'];
        $dobs = $_POST['dob'];
        
        
        
       
        
        
        
        // Now insert the data into the database
        foreach ($names as $index => $name) {
            $roll = strtoupper(trim($roll[$index])); // roll no
            $guardian_name = strtoupper(trim($guardian_names[$index])); // Guardian name
            $dob = trim($dobs[$index]); // Date of Birth
    
            // Debugging: Check if the values are being retrieved correctly
            if (empty($name) || empty($guardian_name) || empty($dob)) {
                echo "<script>alert('Some student details are missing.'); window.location.href='add-student.php';</script>";
                exit;
            }
    
            
            // Insert the data into the database
                $stmt2 = "INSERT INTO `student_details`(`id`, `result_id`,`roll_no`, `name`, `gurdian_name`, `date_of_birth`, `school_id`, `class_id`) VALUES ('','','$roll','$name','$guardian_name','$dob','$id','$class_id')";
                $result2 = $conn->query($stmt2);
                if ($result2) {
                    // Get the last inserted id to calculate result_id
                    $last_id = $conn->insert_id; // Get the last inserted id
                    $result_id = $last_id + 15000; // Calculate result_id
        
                    // Update the record with result_id
                    $update_sql = "UPDATE student_details SET result_id = ? WHERE id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    if ($update_stmt === false) {
                        echo "<script>alert('SQL update prepare statement failed.'); window.location.href='add-student.php';</script>";
                        exit;
                    }
                    $update_stmt->bind_param("ii", $result_id, $last_id);
                    $update_stmt->execute();
                    echo "Record for $name inserted successfully.<br>";
                } else {
                    echo "Error inserting record for $name: <br>";
                }
            
        }
    
        // Success message after all data is inserted
        echo "<script>alert('Student records have been successfully added.'); window.location.href='recent-student-added.php';</script>";
    } else {
        // If no student names are submitted
        echo "<script>alert('No student data submitted.'); window.location.href='add-student.php';</script>";
    }



?>

<?php
include "footer.php";
?>