<?php
include_once "../../config.php";
include "header.php";

$id = $_SESSION['id'];

$result_table_name = $_POST['result_table_name'];
$subject_table_name = $_POST['subject_table_name'];
$class = $_POST['class'];
$session = $_POST['session'];
$section = $_POST['section'];
$exam_name = $_POST['exam_name'];




?>
<style>
    span{
        font-weight:bold;
        font-size:1.3rem;
    }
    h3{
        font-weight:bold;
    }
</style>
<section class="bg-danger text-center my-2 p-0"> <span style="color:white;">Printing in Landscape mode is recomended </span></section>

<section class="card mx-5 " id="print-section">
    <div class="py-2 text-center">
        <h3><?php print $_SESSION['sname']; ?></h3>
    </div>
    <div class="text-center">
        <span class="px-5">Class: <?php print $class; ?></span>
        <span class="px-5">Session: <?php print $session; ?></span>
        <span class="px-5">Section: <?php print $section; ?></span> <br>
        <span>Exam: <?php print $exam_name; ?></span>
    </div>
    <br>
    <div class="overflow-auto">
        <?php
        // Fetching the subject names for the headers
        $subject_query = "SELECT `subject_name` FROM `$subject_table_name`";
        $subject_result = $conn->query($subject_query);
        
        // Fetching the results from the result table
        $result_query = "SELECT * FROM `$result_table_name`";
        $result_data = $conn->query($result_query);
        ?>
        
        <table class="table text-center m-3 border">
            <thead class="table-active">
                <tr>
                    <th>Roll no</th>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <?php
                    // Output subject names as table headers
                    if ($subject_result && $subject_result->num_rows > 0) {
                        while ($row = $subject_result->fetch_assoc()) {
                            echo '<th>' . htmlspecialchars($row['subject_name']) . '</th>';
                        }
                    }
                    ?>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Check if result data is available
                if ($result_data && $result_data->num_rows > 0) {
                    while ($data_row = $result_data->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($data_row['Roll_no']) . '</td>'; // Roll no
                        echo '<td>'. htmlspecialchars($data_row['student_id']) .'</td>';// student id
                        echo '<td>' . htmlspecialchars($data_row['student_name']) . '</td>'; // Student Name
                        
                        // Output subject marks
                        if ($subject_result && $subject_result->num_rows > 0) {
                            // Reset subject result cursor
                            $subject_result->data_seek(0);
                            while ($subject_row = $subject_result->fetch_assoc()) {
                                // Get the subject name
                                $subject_name = $subject_row['subject_name']; // Convert subject name to lowercase
                                // Print the subject mark from the result table
                                echo '<td>' . htmlspecialchars($data_row[$subject_name]) . '</td>'; // Fetch subject score
                            }
                        }
        
                        echo '<td>' . htmlspecialchars($data_row['remark']) . '</td>'; // Remark
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="100%">No data found.</td></tr>';
                }
                ?>
            </tbody>
        </table>


    </div>
    
</section>
<div class="text-center mt-3">
    <button onclick="printSection()" class="btn btn-primary">Print</button>
</div>

<!-- print function -->

<script>
    function printSection() {
        var printContents = document.getElementById('print-section').innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>


<?php
include "footer.php";
?>