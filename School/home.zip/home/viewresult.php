<?php
include_once "../../config.php";
include_once "header.php";
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Check if the user is not logged in
if ($_SESSION['login'] != true) {
    header("location:../index.php");
    exit;
}

// Define the uploadResult function
function uploadResult($conn, $subject_table_name, $result_table_name, $file)
{
    // Step 1: Check if the result table exists
    $checkTableSql = "SHOW TABLES LIKE '$result_table_name'";
    $result = $conn->query($checkTableSql);

    if ($result->num_rows == 0) {
        // Table does not exist, create it
        $sqlCreate = "CREATE TABLE `$result_table_name` (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            Roll_no VARCHAR(255),
            student_name VARCHAR(255),
            father_name VARCHAR(255),
            date_of_birth DATE";

        // Step 2: Add columns for each subject in the subject table
        $subjectSql = "SELECT `subject_name` FROM `$subject_table_name` WHERE 1";
        $subjectResult = $conn->query($subjectSql);

        if ($subjectResult->num_rows > 0) {
            while ($row = $subjectResult->fetch_assoc()) {
                $subjectName = trim($row['subject_name']); // Trim any spaces
                $subjectName = mysqli_real_escape_string($conn, $subjectName); // Escape the subject name
                $sqlCreate .= ", `$subjectName` FLOAT";
            }
        }

        $sqlCreate .= ")";
        if ($conn->query($sqlCreate) === TRUE) {
            echo "Table  created successfully.<br>";
        } else {
            echo "Error creating table: " . $conn->error . "<br>";
            return;
        }
    }

    // Step 3: Upload the spreadsheet data to the table
    if ($file['error'] === UPLOAD_ERR_OK) {
        $allowed = ['xls', 'csv', 'xlsx'];
        $filename = $file['name'];
        $checking = explode('.', $filename);
        $file_ext = end($checking);

        if (in_array($file_ext, $allowed)) {
            $target = $file['tmp_name'];
            $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($target);
            $data = $spreadsheet->getActiveSheet()->toArray();

            foreach ($data as $row) {
                $roll_no = $row[0];
                $student_name = $row[1];
                $father_name = $row[2];
                $dob = date('Y-m-d', strtotime($row[3])); // Convert date to Y-m-d format

                $subjectValues = array_slice($row, 4); // Get the subject marks

                $sqlInsert = "INSERT INTO `$result_table_name` (Roll_no, student_name, father_name, date_of_birth";

                // Add subject columns dynamically
                $subjectSql = "SELECT subject_name FROM `$subject_table_name` WHERE 1";
                $subjectResult = $conn->query($subjectSql);

                $values = "'$roll_no', '$student_name', '$father_name', '$dob'";

                if ($subjectResult->num_rows > 0) {
                    $subjectResult->data_seek(0); // Reset the result set pointer to the beginning
                    foreach ($subjectValues as $index => $value) {
                        $subjectName = trim($subjectResult->fetch_assoc()['subject_name']);
                        $subjectName = mysqli_real_escape_string($conn, $subjectName);
                        $sqlInsert .= ", `$subjectName`";
                        $values .= ", '$value'";
                    }
                }

                $sqlInsert .= ") VALUES ($values)";
                if ($conn->query($sqlInsert) === TRUE) {
                    echo "Data inserted successfully.<br>";
                } else {
                    echo "Error inserting data: " . $conn->error . "<br>";
                }
            }

        } else {
            echo "<script>alert('Wrong file type');</script>";
            echo "<script>window.location.href = 'add-class.php';</script>";
            exit; 
        }
    } else {
        echo "Error uploading file: " . $file['error'] . "<br>";
    }

    // Fetch school details
    $school_id = $_SESSION['id'];
    $query2 = "SELECT * FROM `school_details` WHERE `id`= '$school_id'";
    $res2 = $conn->query($query2);
    $srow = $res2->fetch_assoc();
    $school_name = $srow['school_name'];
    $school_add = $srow['address'];
    $school_pin = $srow['pin_code'];

    // Fetch class details
    $class_id = $_SESSION['cid'];
    $class_table = $school_id . '_class_details';
    $query3 = "SELECT * FROM `$class_table` WHERE `id` = '$class_id'";
    $res3 = $conn->query($query3); // Corrected from $query2 to $query3
    $crow = $res3->fetch_assoc();
    $class = $crow['class_no'];
    $section = $crow['section'];
    $session = $crow['session'];

    // Fetch exam name
    $exam_name = $_SESSION['exam_name'];

    // Insert into published_result table
    $query = "INSERT INTO `published_result`(`school_name`, `school_add`, `school_pin`, `class`, `section`, `session`, `exam_name`, `result_table_name`, `subject_table_name`) 
          VALUES ('$school_name', '$school_add', '$school_pin', '$class', '$section', '$session', '$exam_name', '$result_table_name', '$subject_table_name')";

    if ($conn->query($query) === TRUE) {
        echo "Published result record added successfully.<br>";
    } else {
        echo "Error inserting published result data: " . $conn->error . "<br>";
    }

    // Redirect after success
    echo "<script>alert('Upload was successful');</script>";
    echo "<script>window.location.href = 'add-class.php';</script>";
    
}





// Get form data if available
$subject_table_name = $_POST['subject_table_name'] ?? '';
$exam_name = $_POST['exam_name'] ?? '';
$result_table_name = $_SESSION['rtn'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['result'])) {
        uploadResult($conn, $subject_table_name, $result_table_name, $_FILES['result']);
    } else {
        echo "No file uploaded.<br>";
    }
}
?>

<section class="container mb-5">
    <div>
        <h2 class="fw-bold ls-tight" style="color: hsl(218, 81%, 55%)">Make sure the Result | now
            <button class="btn btn-lg btn-danger"
                onclick="document.getElementById('uploadForm').submit();">UPLOAD</button>
        </h2>
    </div>
    <div class="overflow-auto">
        <form id="uploadForm" method="POST" enctype="multipart/form-data">
            <input type="file" name="result" required>
            <input type="hidden" name="subject_table_name" value="<?php echo $subject_table_name; ?>">
            <input type="hidden" name="exam_name" value="<?php echo $exam_name; ?>">
        </form>
        <table class="table table-striped overflow-auto">
            <thead class="table-dark">
                <tr>
                    <th scope="col">ROLL</th>
                    <th scope="col">FULL NAME</th>
                    <th scope="col">Father name</th>
                    <th scope="col">DOB</th>
                    <?php
                    $sql2 = "SELECT * FROM `$subject_table_name` WHERE 1";
                    $result2 = $conn->query($sql2);
                    if ($result2->num_rows > 0) {
                        while ($row2 = $result2->fetch_assoc()) {
                            print '<th scope="col">' . htmlspecialchars(trim($row2['subject_name'])) . '</th>';
                        }
                    }
                    ?>
                </tr>
            </thead>
            <tbody>
                <!-- Data from uploaded Excel file will be displayed here -->
            </tbody>
        </table>
    </div>
</section>

<?php
include "footer.php";
?>